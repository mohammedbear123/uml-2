﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uml_2_big_mammas_pizza
{
    public class MenuCatalog
    {
        List<Pizza> pizzas = new List<Pizza>();

        public MenuCatalog()
        {
            Pizza p1 = new Pizza("Salat pizza", 70, 1);
            Pizza p2 = new Pizza("Magharita", 80, 2);
            Pizza p3 = new Pizza("Big mammas pizza", 65, 3);
            pizzas.Add(p1);
            pizzas.Add(p2);
        } 
        public void CreatePizza(string Name, int Price, int Number)
        {
            Pizza p = new Pizza(Name, Price, Number);
            pizzas.Add(p);
        }
     
        public void RemovePizza(string Name)
        {

            foreach (var pizzaB in pizzas)
            {

                if (Name.Equals(pizzaB.GetName()))
                {
                    pizzas.Remove(pizzaB);
                    Console.WriteLine($" Pizza {pizzaB} is now deleted");
                    break;

                }
            }
        }
        public void PrintPizza()
        {
            foreach (var pizza in pizzas)
            {
                Console.WriteLine(pizza);

            }

        }
        public void UpdatePizza(string Name, int Price, int Number)
        {
            foreach (var pizza in pizzas)
            {
                if (Number == pizza.GetNumber())
                {
                    pizza.SetName(Name);
                    pizza.SetPrice(Price);
                    Console.WriteLine("Pizza er blevet opdateret !");
                    break;
                }

            }
        }

        public void SearchPizza(string Name)
        {
            foreach (var pizza in pizzas)
            {
                if (pizza.GetName().Contains(Name))
                {
                    Console.WriteLine($"{pizza}");
                }
            }
        }
    }
}