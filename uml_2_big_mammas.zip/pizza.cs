﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uml_2_big_mammas_pizza
{
    public class Pizza
    {
        public int Number { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public Pizza(string Name, int Price, int Number)
        {
            this.Name = Name;
            this.Price = Price;
            this.Number = Number;
        }

        public void SetName(string Name)
        {
            this.Name = Name;
        }
        public string GetName()
        {
            return Name;
        }
        public void SetPrice(int Price)
        {
            this.Price = Price;
        }
        public double GetPrice()
        {
            return Price;
        }
    
        public void SetNumber(int Number)
        {
            this.Number = Number;
        }
        public int GetNumber()
        {
            return Number;
        }

        public override string ToString()
        {
            return $"Number: {Number}, Name: {Name}, Price: {Price}";
        }
    }
}