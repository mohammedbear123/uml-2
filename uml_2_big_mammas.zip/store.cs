﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Formats.Asn1.AsnWriter;

namespace uml_2_big_mammas_pizza
{
    public class Store
    {
        public void Start()
        {
            MenuCatalog menu = new MenuCatalog();

            while (true)
            {
                try
                {
                    Console.WriteLine("0 - Forlad : ");
                    Console.WriteLine("1 - Oversigt : ");
                    Console.WriteLine("2 - Tilføj : ");
                    Console.WriteLine("3 - Slette : ");
                    Console.WriteLine("4 - Opdatere : ");
                    Console.WriteLine("5 - Søg : ");
                    Console.Write("Vælg : ");

                    int option = Int32.Parse(Console.ReadLine());
                    if (option == 0)
                    {
                        break;
                    }
                    //quit            


                    else if (option == 1)
                    
                    {
                        menu.PrintPizza();
                    }
                    
                    else if (option == 2)
                    {
                        Console.Write("Skriv Pizza Name : ");
                        string Name = Console.ReadLine();

                        Console.Write("Skriv Price : ");
                        int Price = Int32.Parse(Console.ReadLine());

                        Console.Write("Skriv Number : ");
                        int Number = Int32.Parse(Console.ReadLine());

                        menu.CreatePizza(Name, Price, Number);
                    }
                    else if (option == 3)
                    {  
                        Console.Write("To Remove, type Name : ");
                        string Name = Console.ReadLine();


                        menu.RemovePizza(Name);

                    }
                    else if (option == 4)
                    {
                        Console.Write(" Nummeret for at søge : ");
                        int Number = Int32.Parse(Console.ReadLine());

                        Console.Write(" Navnet : ");
                        string Name = Console.ReadLine();

                        Console.Write(" Prisen: ");
                        int Price = Int32.Parse(Console.ReadLine());

                        menu.UpdatePizza(Name, Price, Number);
                    }
                    else if (option == 5)
                    {
                        Console.Write("Skriv for at søge : ");
                        string Name = Console.ReadLine();

                        menu.SearchPizza(Name);
                    }
                    else
                    {
                        Console.WriteLine("Fejl, skriv et gyldigt nummer");
                    }

                }
                catch { Console.WriteLine("Fejl, skriv et gyldigt nummer"); }
            }
        }


    }

}