﻿using System;
using static System.Formats.Asn1.AsnWriter;

namespace uml_2_big_mammas_pizza
  
{
    class Program
    {
        static void Main(string[] args)
        {
            Store s = new Store();
            s.Start();
            Console.WriteLine();


        }
    }
}

